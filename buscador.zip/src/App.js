import { useState } from 'react';
import { FiSearch } from 'react-icons/fi'
import './style.css'
import api from './services/api.service'

function App() {

  const [input, setInput] = useState('')
  const [cep, setCep] = useState({})

  async function handleSearch() {
    if (input === '') {
      alert("escreva um cep")
      return
    }
    try {

      const response = await api.get(`${input}/json`);
      console.log(response)
      setCep(response.data)
    } catch {
      alert("errorr")
      setInput("")
    }
  }


  return (
    <div className="container">
      <h1 className="title"> Buscador de cep</h1>
      <div className="containerInput">
        <input type="text" placeholder="Digite seu cep" value={input} onChange={(e) => setInput(e.target.value)} />
        <button className="buttonSearch" onClick={handleSearch}>
          <FiSearch size={25} color="#FFFF" />
        </button>
      </div>
      {Object.keys(cep).length > 0 && (
        <main className="main">
          <h2>CEP: {cep.cep}</h2>
          <span>Cidade: <a>{cep.localidade}</a></span>
          <span>Logradouro: {cep.logradouro}</span>
          <span>Bairro: {cep.bairro}</span>
          <span>UF: {cep.uf}</span>
          <span>Complemento: {cep.complemento}</span>

        </main>
      )}

    </div>
  );
}

export default App;
